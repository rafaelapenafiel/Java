/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pratica4heranca.questao2;

/**
 *
 * @author Rafaela Penafiel
 */
public class Cachorro extends Animal{
    private String raça;
    
    public Cachorro (String nome, double peso, String raça){
        super (nome, peso);
        this.raça = raça;
    }

    public String getRaça() {
        return raça;
    }

    public void setRaça(String raça) {
        this.raça = raça;
    }
    public void imprimir(){
    System.out.println("Cachorro: "+ nome + ", Peso: "+ peso + ", Raça: "+ raça);
    }
}
