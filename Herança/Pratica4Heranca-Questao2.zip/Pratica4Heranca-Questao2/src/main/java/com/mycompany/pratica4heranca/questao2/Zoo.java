/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.pratica4heranca.questao2;

/**
 *
 * @author Rafaela Penafiel
 */
public class Zoo {

    public static void main(String[] args) {
        Peixe p1 = new Peixe ("Dory", 0.50, "Aquário");
        Peixe p2 = new Peixe ("Marlin", 0.60, "Mar");
        Cachorro c1 = new Cachorro ("Victor Hugo", 6.0 , "Pequinês");
        Cachorro c2 = new Cachorro ("Mendigo", 10.0, "Vira-lata");
        
        System.out.println("Nome: "+ p1.getNome()+ " Peso: "+ p1.getPeso()+ " Habitat: " + p1.getTipoHabitat());
        System.out.println("Nome: "+ p2.getNome()+ " Peso: "+ p2.getPeso()+ " Habitat: " + p2.getTipoHabitat());
        System.out.println("Nome: "+ c1.getNome()+ " Peso: "+ c1.getPeso()+ " Raça: " + c1.getRaça());
        System.out.println("Nome: "+ c2.getNome()+ " Peso: "+ c2.getPeso()+ " Raça: " + c2.getRaça());
    }
}
